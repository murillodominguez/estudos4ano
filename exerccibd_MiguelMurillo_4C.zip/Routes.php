<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

//Terraria Bosses

$routes->get('/terrariaindex', 'TerrariaBosses::index');
$routes->post('/terrariaindex', 'TerrariaBosses::update');
$routes->get('/terrariaform', 'TerrariaBosses::form');
$routes->post('/delete', 'TerrariaBosses::delete');
