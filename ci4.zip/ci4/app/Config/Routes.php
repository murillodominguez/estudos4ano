<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/exerc1', 'Exerc1Controller::index');
$routes->post('/update', 'Exerc1Controller::update');
