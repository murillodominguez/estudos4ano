<?php

namespace App\Controllers;

use App\Models\BiblioModel;

class BiblioController extends BaseController
{
    public function index()
    {
        return view('bibliotemplate');
    }

    public function loginpage($error)
    {
        $bodycontent = "
        <div class='sign'>
          <div class='loginContainer'>
            <h1 class='loginTitle'>Login</h1>
            <form action='login' method='post' class='login'>
              <div class='formgroup'>
              ".(isset($error)?$error:null)."
              <label for='email'>Email:</label>
              <input type='text' name='email' id='email' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='password' required>
              <button type='submit'>Entrar</button>
              </div>
            </form>
          </div>
          <div class='separator'></div>
          <div class='signUpContainer'>
            <h1 class='loginTitle bold'>Ainda não possui uma conta? Registre-se:</h1>
            <form action='cadastro' method='post' class='login'>
              <div class='formgroup'>
              <label for='username'>Nome de usuário:</label>
              <input type='text' name='username' id='username' required>
              <label for='emailRegister'>Email:</label>
              <input type='text' name='email' id='emailRegister' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='passwordRegister' required>
              <button type='submit'>Registrar</button>
              </div>
            </form>
          </div>
        </div>
        ";

        $data['bodycontent'] = $bodycontent;

        return view('bibliotemplate', $data);
    }

    public function login()
    {
        $myModel = new BiblioModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        if(!$this->verifyUserEmailFromDatabase($email)){
          $error = "
            <div class='error'>
              O nome de usuário não confere!
            </div>
          ";
          return $this->loginpage($error);
        }
        return view('bibliotemplate');
    }

    public function registerpage()
    {
        $bodycontent = "
            <div class='signUpContainer' style='margin: 0 auto'>
            <h1 class='loginTitle'>Registro</h1>
            <form action='cadastro' method='post' class='login'>
              <div class='formgroup'>
              <label for='username'>Nome de usuário:</label>
              <input type='text' name='username' id='username' required>
              <label for='email'>Email:</label>
              <input type='text' name='email' id='email' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='password' required>
              <button type='submit'>Registrar</button>
              </div>
            </form>
          </div>
        ";
        
        $data['bodycontent'] = $bodycontent;

        return view('bibliotemplate', $data);
    }

    public function register()
    {   
        $myModel = new BiblioModel();

        $data = array(
          'username' => $this->request->getVar('username'),
          'email' => $this->request->getVar('email'),
          'token' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT)
        );

        $myModel->insert($data);
        
        return redirect()->to('index');
    }

    public function verifyUserEmailFromDatabase($email)
    {
        $myModel = new BiblioModel();
        $user = $myModel->getWhere(['email' => $email])->getRowArray();
        if(empty($user)) return false;
        return true;
    }
}