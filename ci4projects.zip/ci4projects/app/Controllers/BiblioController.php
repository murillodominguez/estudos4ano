<?php

namespace App\Controllers;

use App\Models\BiblioModel;
use App\Models\BiblioBooks;
use App\Models\BiblioRelations;

class BiblioController extends BaseController
{   
    public function index()
    {
        var_dump($_SESSION);
        return view('bibliotemplate');
    }

    public function loginpage($msg = null)
    {
        $bodycontent = "
        <div class='sign'>
          <div class='loginContainer'>
            <h1 class='loginTitle'>Login</h1>
            <form action='login' method='post' class='login'>
              <div class='formgroup'>
              ".((isset($msg) && !empty($msg))?$msg:null)."
              <label for='email'>Email:</label>
              <input type='email' name='email' id='email' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='password' required>
              <button type='submit'>Entrar</button>
              </div>
            </form>
          </div>
          <div class='separator'></div>
          <div class='signUpContainer'>
            <h1 class='loginTitle bold'>Ainda não possui uma conta? Registre-se:</h1>
            <form action='cadastro' method='post' class='login'>
              <div class='formgroup'>
              <label for='username'>Nome de usuário:</label>
              <input type='text' name='username' id='username' required>
              <label for='emailRegister'>Email:</label>
              <input type='text' name='email' id='emailRegister' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='passwordRegister' required>
              <button type='submit'>Registrar</button>
              </div>
            </form>
          </div>
        </div>
        ";

        $data['bodycontent'] = $bodycontent;

        return view('bibliotemplate', $data);
    }

    public function login()
    {
        $myModel = new BiblioModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        if($myModel->getWhere(['email'=>$email])->getRowArray()){
          $username = $myModel->getWhere(['email'=>$email])->getRowArray()['username'];
        }
        // $username = $myModel->getWhere(['email'=>$email])->getRowArray()['username'];
        if(!$this->verifyUserEmailFromDatabase($email)){
          $error = "
            <div class='error'>
              O nome de usuário não confere!
            </div>
          ";
          return $this->loginpage($error);
        }
        if(!$this->verifyUserPasswordFromDatabase($password, $email)){
          $error = "
            <div class='error'>
              A senha não confere!
            </div>
          ";
          return $this->loginpage($error);
        }
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $email;
        $_SESSION['nickname'] = $username;
        $_SESSION['password'] = $password;
        return view('bibliotemplate');
    }

    public function logout()
    {
        session_destroy();
        $_SESSION['logged_in'] = false;
        return redirect()->to('index');
    }

    public function registerpage()
    {
        $bodycontent = "
            <div class='signUpContainer' style='margin: 0 auto'>
            <h1 class='loginTitle'>Registro</h1>
            <form action='cadastro' method='post' class='login'>
              <div class='formgroup'>
              <label for='username'>Nome de usuário:</label>
              <input type='text' name='username' id='username' required>
              <label for='email'>Email:</label>
              <input type='text' name='email' id='email' required>
              <label for='password'>Senha:</label>
              <input type='password' name='password' id='password' required>
              <button type='submit'>Registrar</button>
              </div>
            </form>
          </div>
        ";
        $data['bodycontent'] = $bodycontent;

        return view('bibliotemplate', $data);
    }

    public function register()
    {   
        $myModel = new BiblioModel();

        $data = array(
          'username' => $this->request->getVar('username'),
          'email' => $this->request->getVar('email'),
          'token' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT)
        );

        $myModel->insert($data);
        
        $this->session->setFlashdata('item', 'Usuário Registrado com Sucesso!');
        print_r($_SESSION['item']);
        return redirect()->to('login');
    }

    public function verifyUserEmailFromDatabase($email)
    {
        $myModel = new BiblioModel();
        $user = $myModel->getWhere(['email' => $email])->getRowArray();
        if(empty($user)) return false;
        return true;
    }

    public function verifyUserPasswordFromDatabase($password, $email)
    {
        $myModel = new BiblioModel();
        $token = $myModel->getWhere(['email'=>$email])->getRowArray()['token'];
        if(password_verify($password, $token)) return true;
        return false;
    }

    public function booksPage()
    {
      $myModel = new BiblioBooks();
      $result = $myModel->findAll();
      $bodycontent = "<div class='listHeader'>
        <h1 class='listTitle'>LISTA DE LIVROS REGISTRADOS</h1>
        <a class='insertbutton' href='insertbooks'>Inserir +</a>
      </div>";
      $tableitems = '';
      if(isset($result) && !empty($result)){
        $bodycontent.="<table>
        <thead>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>Autores</th>
                <th>Ano de publicação</th>
                <th>Editora</th>
                <th>Quant.</th>
                <th colspan='2' class='toolColumn'>Ferramentas</th>
            </tr>
        </thead>
        <tbody>";
        foreach($result as $row){
          $tableitems.= "<tr>";
          foreach($row as $value){
              $tableitems.= '<td>'.$value.'</td>';
          }   
          $tableitems.=
          "<td>
          <div class='form-group tools'>
          <form action='deletebooks' method='post'>
          <input type='hidden' value=".$row['id']." name='id'>
          <button type='submit'><i class='fa-solid fa-trash'></i></button>
          </form>
          <form action='editbooks' method='post'>
          <input type='hidden' value=".$row['id']." name='id'>
          <button type='submit'><i class='fa-solid fa-pen-to-square'></i></button>
          </form>
          </div>
          </td>
          </tr>";
      }
      $bodycontent.=$tableitems;
      $bodycontent.="</tbody>
      </table>";
    }
    $data['bodycontent'] = $bodycontent;
    return view('bibliotemplate', $data);
  }


    public function insertBooksPage()
    {
        $bodycontent = "
        <div class='listHeader'>
        <h1 class='listTitle'>CADASTRO DE LIVROS</h1>
        </div>
        <form action='insertbooks' method='post' class='login'>
        <div class='formgroup'>
        <label for='author'>Autores:</label>
        <input type='text' name='author' id='author' required>
        <label for='title'>Título do Livro:</label>
        <input type='text' name='title' id='title' required>
        <label for='year'>Ano de publicação:</label>
        <input type='text' name='year' id='year' required>
        <label for='editor'>Editora:</label>
        <input type='text' name='editor' id='editor' required>
        <label for='quant'>Quantidade de cópias disponíveis:</label>
        <input type='number' name='quant' id='quant' required>
        <button type='submit'>Registrar</button>
        </div>
        </form>
        ";
        $data['bodycontent'] = $bodycontent;
        return view('bibliotemplate', $data);
    }

    public function insertBooks()
    {
        $myModel = new BiblioBooks();
        $data = array(
          'title' => $this->request->getVar('title'),
          'author' => $this->request->getVar('author'),
          'year' => $this->request->getVar('year'),
          'editor' => $this->request->getVar('editor'),
          'quant' => $this->request->getVar('quant')
        );
        $myModel->insert($data);
        // $this->session->setFlashdata('item', 'Livro Inserido com Sucesso!');
        return redirect()->to('books')->with('item', 'Livro Inserido com Sucesso!');
    }

    public function deleteBooks()
    {
      $myModel = new BiblioBooks();
      $id = $this->request->getVar('id');
      $myModel->delete($id);
      return redirect()->to('books');
    }

    public function editBooksPage()
    {
      $myModel = new BiblioBooks();
      $id = $this->request->getVar('id');
      $result = $myModel->find($id);
      $bodycontent = "
        <div class='listHeader'>
        <h1 class='listTitle'>ALTERAR LIVRO</h1>
        </div>
        <form action='updatebooks' method='post' class='login'>
        <div class='formgroup'>
        <input type='hidden' name='id' value='".$id."' id='id'>
        <label for='author'>Autores:</label>
        <input type='text' name='author' value='".$result['author']."' id='author' required>
        <label for='title'>Título do Livro:</label>
        <input type='text' name='title' value='".$result['title']."' id='title' required>
        <label for='year'>Ano de publicação:</label>
        <input type='text' name='year' value='".$result['year']."' id='year' required>
        <label for='editor'>Editora:</label>
        <input type='text' name='editor' value='".$result['editor']."' id='editor' required>
        <label for='quant'>Quantidade de cópias disponíveis:</label>
        <input type='number' name='quant' value='".$result['quant']."' id='quant' required>
        <button type='submit'>Registrar</button>
        </div>
        </form>
        ";
        $data['bodycontent'] = $bodycontent;
        return view('bibliotemplate', $data);
    }

    public function updateBooks()
    {
      $myModel = new BiblioBooks();
      $id = $this->request->getVar('id');
      $data = array(
        'title' => $this->request->getVar('title'),
        'author' => $this->request->getVar('author'),
        'year' => $this->request->getVar('year'),
        'editor' => $this->request->getVar('editor'),
        'quant' => $this->request->getVar('quant')
      );
      $myModel->update($id,$data);
      // $this->session->setFlashdata('item', 'Livro Atualizado com Sucesso!');
      return redirect()->to('books')->with('item', 'Livro Atualizado com Sucesso!');
    }

    //Ver quantidade de livros
    public function isBookAvailable(){
      $myModel = new BiblioBooks();
      $id = $this->request->getVar('id');

      $myModel->find($id);
    }

    public function linkUsersWithBooks($userid, $bookid){
      $UsersModel = new BiblioModel(); 
      $BooksModel = new BiblioBooks();
      $RelationsModel = new BiblioRelations();
      $data = array(
        'id_user' => $UsersModel->getWhere(['email' => $_SESSION['username']])->getRowArray['id'],
        'id_liv' => $this->request->getVar('bookid')
      );
      $RelationsModel->insert($data);
    }


}