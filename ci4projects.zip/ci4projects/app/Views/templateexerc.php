<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles/exerc1.css">
    <title>VALOR DE RESSARCIMENTO</title>
</head>
<body>
    <header>
        <a href="exerc1"><img src="Images/caixa.png"></a>
        <h1>RESSARCIMENTO DE VALORES</h1>
    </header>
    <main>
    <?php
        echo $bodycontent;
    ?>
    </main>
</body>