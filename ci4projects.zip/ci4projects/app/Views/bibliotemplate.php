<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel= 'stylesheet' type='text/css' href="styles/biblio.css">
  <title>Bibl.io</title>
</head>
<body>
  <header>
    <a href="index" class="logo"><img width="70px" height="48.125px" src="Images/biblio.png"><h1 class="logotext">Biblio</h1></a>
    <nav>
      <?php
      if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true){
        echo "<h1 style='color: white'>".$_SESSION['nickname']."</h1>
        <a href='books'><h1>Livros</h1></a>
        <a href='logout'><h1>Logout</h1></a>";
      }
      else{
      echo "<a href='login'><h1>Login</h1></a>
      <a href='cadastro'><h1>Cadastro</h1></a>";
      }
      ?>
    </nav>
  </header>
  <main>
    <?php
     if(session()->getFlashdata('item')!=null){
      echo "<div class='alert-success'><h1>".session()->getFlashdata('item')."</h1></div>";
    }
    ?>
    <?php if(isset($bodycontent))echo $bodycontent ?>
  </main>
</body>
</html>